using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

public class RegisterModel : PageModel
{
    [BindProperty]
    [Required(ErrorMessage = "Введите номер телефона")]
    [Phone(ErrorMessage = "Неверный формат телефона")]
    public string PhoneNumber { get; set; }

    [BindProperty]
    [Required(ErrorMessage = "Введите пароль")]
    public string Password { get; set; }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        // Здесь логика регистрации пользователя
        // Например, сохранить в базу данных

        return RedirectToPage("/Login"); // После регистрации — на вход
    }
}
