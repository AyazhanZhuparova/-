using Microsoft.AspNetCore.Mvc.RazorPages;

public class CatalogModel : PageModel
{
    public void OnGet()
    {
    }
}
