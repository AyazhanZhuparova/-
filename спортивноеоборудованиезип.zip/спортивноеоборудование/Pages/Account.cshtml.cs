using Microsoft.AspNetCore.Mvc.RazorPages;

public class AccountModel : PageModel
{
    public void OnGet()
    {
    }
}
